// src/midlewares/validateSchema.midleware.ts
import { AnySchema, ValidationError } from 'yup';
import { Request, Response, NextFunction } from 'express';

const validateSchemaYup = (schema: AnySchema) => async (
    req: Request,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        await schema.validate(req.body, {
            abortEarly: false,
            stripUnknown: true,
        });

        next();
    } catch (err) {
        if (err instanceof ValidationError) {
            res.status(400).json({
                statusCode: 400,
                message: err.errors,
                typeError: 'validateSchema',
            });
            return;
        }

        res.status(500).json({
            statusCode: 500,
            message: 'validate Yup Error',
            typeError: 'validateSchemaUnknown',
        });
    }
};

export default validateSchemaYup;
