import createHttpError from "http-errors";
import Product from "../models/Product.model";
import { Query } from "mongoose";

export const findAll = async (query: any) => {
    console.log(query);

    const page = parseInt(query.page) || 1;
    const keyword = parseInt(query.keyword) || null;
    const limit = parseInt(query.limit) || 5;
    const cat_id = parseInt(query.cat_id) || null;
    const brand_id = parseInt(query.brand_id) || null;
    const skip = (page - 1) * limit;

    const where: any = {};
    if (keyword) {
        where.product_name = { $regex: keyword, $options: 'i' }
    }
    if (cat_id) {
        where.category_id = cat_id;
    }
    if (brand_id) {
        where.brand_id = brand_id;
    }
    const products = await Product.find({ ...where })
        .skip(skip)
        .limit(limit)
        .sort({ createdAt: -1 })
        .populate("category_id", "category_name")
        .populate("brand_id", "brand_name");

    return {
        products,
        page,
        limit,
        totalRecord: await Product.countDocuments(),
    }
};
