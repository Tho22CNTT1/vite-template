import express from 'express';
import orderController from '../../controllers/order.controller';

const router = express.Router();

router.get('/', orderController.getOrders);
router.get('/:id', orderController.getOrder);
router.post('/', orderController.createOrder);
router.delete('/:id', orderController.deleteOrder);

export default router;
