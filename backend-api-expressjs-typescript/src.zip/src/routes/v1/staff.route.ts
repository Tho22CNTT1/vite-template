// src/routes/api/staff.route.ts
import express from 'express';
import * as staffController from '../../controllers/staff.controller';
import { routeStaffMidleware } from '../../midlewares/routeStaf.middleware';
import { routeStaffMidleware2 } from '../../midlewares/routeStaff2.midleware';
import staffValidation from '../../validations/staff.validation';
import validateSchemaYup from '../../midlewares/validateSchema.midleware';

const router = express.Router();

router.use(routeStaffMidleware);

router.get('/', routeStaffMidleware2, staffController.findAll);

router.post(
    '/',
    validateSchemaYup(staffValidation.createStaff),
    staffController.create
);

export default router;
