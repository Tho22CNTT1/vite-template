import express from 'express';
import staffRouter from './staff.route';

const router = express.Router();

router.use('/staffs', staffRouter);

export default router;
