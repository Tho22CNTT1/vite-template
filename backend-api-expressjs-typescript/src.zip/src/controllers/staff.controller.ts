import { Request, Response, NextFunction } from 'express';
import Staff from '../models/Staff.model';
import createHttpError from 'http-errors';
import * as staffService from '../services/staffs.service';



export const create = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const { first_name, last_name, phone, email, password, store_id, manage_id } = req.body;

        // Kiểm tra các trường bắt buộc
        if (!first_name || !last_name || !phone || !email || !password || !store_id) {
            throw createHttpError(400, 'Missing required fields');
        }

        const newStaff = await Staff.create({
            first_name,
            last_name,
            phone,
            email,
            password, // Nếu bạn cần hash mật khẩu, có thể thêm bcrypt tại đây
            store_id,
            manage_id,
        });

        res.status(201).json({
            status: 'success',
            message: 'Staff created successfully',
            data: newStaff,
        });
    } catch (error) {
        next(error);
    }
};

export const findAll = async (req: Request, res: Response) => {
    try {
        const { page = 1, limit = 5 } = req.query;

        const staffs = await staffService.findAll({
            page: Number(page),
            limit: Number(limit),
        });

        res.json(staffs);
    } catch (error) {
        const err = error as Error;
        res.status(500).json({ message: err.message });
    }
};
