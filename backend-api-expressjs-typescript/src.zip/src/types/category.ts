interface ICategoryDTO {
    category_name: String;
    description: String;
    slug: String;
}