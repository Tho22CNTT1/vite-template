// src/validations/staff.validation.ts
import * as yup from 'yup';

const createStaff = yup.object({
    first_name: yup.string().min(2).max(50).required('First name is required'),
    last_name: yup.string().min(2).max(50).required('Last name is required'),
    email: yup.string()
        .email('Email not valid')
        .max(160)
        .required('Email is required'),
    password: yup.string()
        .min(6, 'Password too short')
        .max(255, 'Password too long')
        .required('Password is required'),
    active: yup.boolean().default(true),
    roles: yup.array().of(
        yup.string().oneOf(['staff', 'admin', 'superadmin'])
    ).default(['staff']),
});

export default {
    createStaff,
};
