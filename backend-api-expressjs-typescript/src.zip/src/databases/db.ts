// ✅ Dữ liệu mẫu
export const categories = [
    { id: 1, name: 'E' },
    { id: 2, name: 'B' },
    { id: 3, name: 'N' },
];